# ESCUELA COLOMBIANA DE INGENIERÍA PROGRAMACIÓN
## DESARROLLO ORIENTADO POR OBJETOS
### The DOPO Hardest Game 2026-1

**Autores:** Francisco Gomez · Oscar Lopez

# Planificación de ciclos y mini-ciclos — Todas las versiones

## 1. Resumen de las 4 versiones

| Versión | Entregables anteriores | Nuevos entregables | Ciclos / Mini-ciclos | Fecha límite |
|---|---|---|---|---|
| **V1 — Base** | — | Dominio básico, tablero funcional, jugador con movimiento, enemigos básicos, monedas recolectables | **Ciclo 1:** Modelo de dominio (Cuadrado + movimiento, Tablero + celdas, Enemigos + colisión) · **Ciclo 2:** Vista básica (Renderizado del tablero, Game loop, Input de teclado) | — |
| **V2 — Persistencia + Dominio** | Todo V1 | Dos configuraciones de nivel, modo Player vs Player, guardar y abrir partidas | **Ciclo 2:** Múltiples configs · **Ciclo 2:** Modo PvsP · **Ciclo 2:** Persistencia | S16: Sa may 16 |
| **V3 — Nuevos objetivos y enemigos** | Todo V2 | Monedas skins, Punto azul patrullero, Deslizador vertical (Tipo V), Pruebas de aceptación | **Ciclo 3:** Monedas skins + pruebas JUnit | S17: Ma may 19 |
| **V4 — Nivel 2 + Pulido** | Todo V3 | Punto azul patrullero completo, Deslizador vertical completo, Nivel 2 configurado | **Ciclo 4:** Nuevos enemigos + Nivel 2 | S17: Sa may 23 |

---

## 2. Detalle Versión 2 — Persistencia + Dominio

### Ciclo 2 — Múltiples configuraciones de nivel
**Objetivo:** Soportar más de un nivel cargable sin cambiar el código.

Mini-ciclos:
- Refactor de LectorConfiguracion para ruta dinámica
- Validación: ambos niveles cargan sin errores

**Criterio de aceptación:** Ambos niveles cargan y son jugables sin modificar el código fuente.

### Ciclo 2 — Modo Player vs Player
**Objetivo:** Permitir que dos jugadores jueguen simultáneamente en el mismo tablero.

Mini-ciclos:
- Segundo jugador con flechas
- HUD muestra muertes de J1 y J2 por separado
- Lógica de victoria: primero en llegar al final con todas las monedas gana

**Criterio de aceptación:** Dos jugadores se mueven de forma independiente y el juego detecta al ganador correctamente.

### Ciclo 2 — Guardar y abrir partidas
**Objetivo:** Persistir el estado de la partida en un archivo y poder restaurarlo.

Mini-ciclos:
- GestorPartida.java: serializar estado a .sav
- Botones GUARDAR y CARGAR en el HUD
- Restaurar posición, muertes, monedas y tiempo al cargar

**Criterio de aceptación:** Una partida guardada se puede reabrir y continuar desde el mismo punto.

## 3. Detalle Versión 3 — Nuevos objetivos y enemigos

### Ciclo 3 — Monedas Skins
**Objetivo:** Implementar monedas que cambian temporalmente el skin del jugador al recolectarlas.

Mini-ciclos:
- Crear clase MonedaSkin con atributo skin asociado
- Al recolectar: cambiar apariencia del jugador al skin de la moneda
- El efecto se mantiene hasta recolectar otra moneda o morir
- Al morir: recuperar skin original automáticamente
- Condición de nivel: todas las monedas skins deben recogerse para completar

**Criterio de aceptación:** El jugador cambia de skin al recolectar, lo recupera al morir, y el nivel no se completa si quedan monedas skins sin recoger.

### Ciclo 3 — Pruebas de aceptación
**Objetivo:** Verificar el comportamiento correcto de las monedas skins mediante pruebas JUnit.

Mini-ciclos:
- Prueba: recolectar moneda skin cambia el skin del jugador
- Prueba: morir después de recolectar restaura el skin original
- Prueba: nivel no se completa si hay monedas skins sin recoger
- Prueba: recolectar segunda moneda skin reemplaza el efecto anterior

**Criterio de aceptación:** Todas las pruebas JUnit pasan sin errores.

## 4. Detalle Versión 4 — Nivel 2 + Pulido

### Ciclo 4 — Nuevos enemigos
**Objetivo:** Implementar el Punto azul patrullero y el Deslizador vertical (Tipo V).

Mini-ciclos:
- PuntoPatrullero: movimiento en círculos o figuras geométricas en zona definida
- DeslizadorVertical: movimiento exclusivo en línea recta vertical, rebota en paredes superior e inferior
- Ambos eliminan al jugador al tocarlo y no recolectan monedas
- Integrar ambos enemigos en el tablero

**Criterio de aceptación:** Ambos enemigos se mueven correctamente, eliminan al jugador al contacto y no recolectan monedas.

### Ciclo 4 — Nivel 2
**Objetivo:** Crear modo player vs maquina y usar los nuevos enemigos y monedas skins modo player vs maquina

Mini-ciclos:
- Incluir PuntoPatrullero y DeslizadorVertical en la configuración
- Incluir monedas skins en el nivel 2
- Testing integral: nivel 2 jugable en modo Player y Player vs Player
- Nuevo modo Player vs Maquina

**Criterio de aceptación:** El nivel 2 carga correctamente, es jugable en ambos modos y los nuevos enemigos y monedas skins funcionan sin errores.

## 5. Requisitos que NO se van a considerar

| Requisito | Motivo de exclusión | Posible versión futura |
|---|---|---|
| Sonido / música | Fuera del alcance de las versiones planificadas | No planificado |
| Animaciones de personajes | Complejidad gráfica no requerida | No planificado |
| Ranking / highscores | Requiere estructura adicional de persistencia | No planificado |
| Editor de niveles en-game | Alcance demasiado amplio | No planificado |

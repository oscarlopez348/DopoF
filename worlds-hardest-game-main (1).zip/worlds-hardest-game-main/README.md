# The DOPO Hardest Game

**Autores:** Francisco Gomez · Oscar Lopez  
**Curso:** Programación — Desarrollo Orientado por Objetos · Escuela Colombiana de Ingeniería  
**Semestre:** 2026-1

---

## Tabla de contenidos

1. [Descripción del proyecto](#descripción-del-proyecto)
2. [Arquitectura y temas de clase implementados](#arquitectura-y-temas-de-clase-implementados)
3. [Guía de ejecución desde consola](#guía-de-ejecución-desde-consola)
4. [Controles del juego](#controles-del-juego)
5. [Informe PMD](#informe-pmd)
6. [Informe de cobertura de tests](#informe-de-cobertura-de-tests)

---

## Descripción del proyecto

Clon del clásico *World's Hardest Game* desarrollado en Java con interfaz gráfica Swing. El jugador controla un cuadrado de colores que debe recolectar todas las monedas del tablero y llegar a la zona final sin ser tocado por los enemigos. El proyecto fue construido incrementalmente en 4 versiones a lo largo del semestre:

| Versión | Qué se entregó |
|---------|----------------|
| V1 — Base | Dominio básico: tablero, jugador, enemigos, monedas, game loop |
| V2 — Persistencia | Modo PvsP, guardar/cargar partidas, múltiples configuraciones de nivel |
| V3 — Nuevos objetivos | Monedas skin, pruebas JUnit de aceptación |
| V4 — PvsIA + Pulido | Punto patrullero, Deslizador vertical, Punto acelerado, IA con BFS |

---

## Arquitectura y temas de clase implementados

El proyecto sigue una arquitectura en dos capas: dominio (lógica pura, sin dependencias de GUI) y presentacion (Swing). A continuación se describen los temas vistos en clase y cómo se aplican concretamente en el código.

---

### S01–S03 · Clases, objetos e interacciones

Cada entidad del juego es una clase con responsabilidad única:

- **Celda** — representa una posición en el tablero, con su tipo (TipoCelda).
- **Tablero** — matriz bidimensional de Celda, con métodos de consulta: esTransitable, esTransitablePorEnemigo, getCelda.
- **Nivel** — agrega tablero, monedas, enemigos y zonas; coordina la lógica de colisiones, recolección de monedas y spawn de jugadores.
- **GestorPartida** — responsable exclusivo de serializar y deserializar el estado de partida a un archivo .sav.

---

### S04–S05 · Herencia y polimorfismo

#### Personajes — jerarquía de Cuadrado

La clase abstracta Cuadrado tiene tres subclases: CuadradoRojo (velocidad 1.0, Blinky), CuadradoAzul (velocidad 2.0, tamaño 1.2×, Inky) y CuadradoVerde (lógica especial de resistencia al daño, Clyde).

Cuadrado define el comportamiento base: mover(), morir(), aplicarSkinTemporal(). CuadradoVerde sobreescribe morir() para implementar su mecánica de dos golpes: el primero reduce la velocidad a 0.7× y activa invulnerabilidad temporal; el segundo mata y resetea al spawn.

#### Enemigos — jerarquía de Enemigo

La clase abstracta Enemigo tiene cuatro subclases: PuntoAzulBasico (rebota horizontal o vertical), PuntoAcelerado (doble velocidad, avanza 2 celdas por tick), PuntoAzulPatrullero (recorre el perímetro de un rectángulo definido) y DeslizadorVertical (línea recta vertical, rebota en paredes).

Todos comparten colisionaCon(Cuadrado) definido en la clase base. Cada uno implementa mover(Tablero) con su comportamiento particular.

#### Monedas — jerarquía de Moneda

La clase abstracta Moneda tiene dos subclases: MonedaAmarilla (moneda estándar, color dorado) y MonedaSkin (al recolectarla, cambia el skin visual del jugador).

MonedaSkin registra el skinAsociado (Rojo, Azul o Verde) y expone getSkinAsociado() para que el nivel aplique el efecto temporal sobre el jugador.

---

### S06–S07 · Interfaces y relaciones entre objetos

#### ModoJuego — interfaz de estrategia

La interfaz ModoJuego declara cuatro métodos: iniciar(), verificarVictoria(), actualizar() y getNombre(). Tiene tres implementaciones concretas:

| Clase | Descripción |
|-------|-------------|
| ModoPlayer | Un jugador humano vs enemigos |
| ModoPvsP | Dos jugadores humanos compiten; gana el primero en llegar |
| ModoPlayerVsMaquina | Humano vs IA con BFS; tres niveles de dificultad (FACIL / NORMAL / DIFICIL) |

VentanaPrincipal solo conoce la interfaz ModoJuego, lo que permite cambiar el modo sin tocar el game loop.

#### PanelMenu.MenuListener — interfaz de callback

Desacopla el menú de la ventana principal. El menú emite un evento onPlayGame(skin, skin2, modo, config) y la ventana reacciona sin que el menú sepa nada de cómo se inicializa el juego.

---

### S08 · Lo abstracto y las interfaces

- Cuadrado y Enemigo son clases abstractas: definen la plantilla pero dejan que cada subclase implemente getNombre(), getColor() y mover().
- ModoJuego es una interfaz que permite tratar los tres modos de forma uniforme en el game loop.
- Moneda es abstracta y obliga a sus subclases a implementar getColor().

---

### S09 · Excepciones

JuegoException es una excepción personalizada que extiende RuntimeException y es lanzada por LectorConfiguracion cuando el archivo de nivel no existe, tiene formato inválido o un número malformado. La ventana principal la captura y muestra un diálogo de error al usuario sin colapsar la aplicación.

---

### S12 · GUI (Swing)

- **PanelMenu** — menú con selección de modo, personaje, dificultad de IA y configuración de elementos del nivel. Botones personalizados con paintComponent sobreescrito para diseño propio sin look-and-feel estándar.
- **PanelJuego** — renderizado del tablero celda a celda con Graphics2D, incluyendo ajedrezado, zonas seguras con borde, monedas con óvalo sombreado, etiquetas de tipo de enemigo y los jugadores con label J1/J2.
- **VentanaPrincipal** — manejo de CardLayout para navegar entre menú y juego; KeyEventDispatcher global para capturar todas las teclas incluso cuando el foco no está en el panel; tres Timer (lógica, movimiento J1, movimiento J2) corriendo en paralelo.

---

### S13 · Colecciones

- List de Moneda, Enemigo y Zona en Nivel para iterar y filtrar elementos del nivel.
- Set de Integer teclasPresionadas en VentanaPrincipal para movimiento fluido (detectar varias teclas simultáneas).
- Deque de Direccion caminoIA en ModoPlayerVsMaquina como cola FIFO del camino BFS de la IA.
- Map de String a String en GestorPartida para leer el archivo de partida como pares clave→valor.
- Queue de int[] dentro del BFS para la búsqueda por anchura.

---

### S14 · Entrada–Salida (I/O)

- **LectorConfiguracion** — lee el archivo de nivel (nivel1.txt) línea a línea con BufferedReader y FileReader, parsea el tablero, monedas y enemigos.
- **GestorPartida** — escribe el estado de la partida con PrintWriter y FileWriter, y lo lee con BufferedReader. El formato es texto plano legible con pares clave=valor.
- El nivel se define en un archivo de texto externo (recursos/niveles/nivel1.txt) usando símbolos: # pared, Z zona inicial, F zona final, . libre.

---

### S15 · Patrones de software

| Patrón | Dónde |
|--------|-------|
| **Strategy** | ModoJuego permite intercambiar el modo sin cambiar el game loop |
| **Template Method** | Cuadrado.mover() y Cuadrado.morir() definen el algoritmo; CuadradoVerde sobreescribe morir() con comportamiento especializado |
| **Observer / Callback** | MenuListener desacopla PanelMenu de VentanaPrincipal |
| **Factory Method** | crearCuadrado(skin, fila, col) en VentanaPrincipal centraliza la creación de personajes según el string de skin |

---

## Ejecución desde consola (Windows)

### Requisitos
- Java JDK instalado

### Pasos

**1. Clonar o descargar el repositorio**
```bash
git clone https://github.com/fg08416-rgb/worlds-hardest-game.git
```
O descargar el ZIP desde GitHub → botón verde <> Code → Download ZIP y descomprimir.

**2. Abrir PowerShell en la carpeta del proyecto**

Dentro de la carpeta luego de descomprimir entrar a la subcarpeta WORLDS HARDEST GAME, hacer clic en la barra de direcciones, escribir powershell y presionar Enter.

**3. Compilar**
```powershell
$sources = Get-ChildItem -Recurse -Filter "*.java" src | Select-Object -ExpandProperty FullName
javac -d out $sources
```

**4. Ejecutar**
```powershell
java -cp out Main
```

---

## Ejecutar pruebas (Tests)

**1. Los JARs de JUnit ya están incluidos en la carpeta lib/**

**2. Compilar**
```powershell
$sources = Get-ChildItem -Recurse -Filter "*.java" src | Select-Object -ExpandProperty FullName
$tests = Get-ChildItem -Recurse -Filter "*.java" test | Select-Object -ExpandProperty FullName
javac -d out -cp "lib/*" ($sources + $tests)
```

**3. Ejecutar tests**
```powershell
java -jar "lib\junit-platform-console-standalone-1.10.2.jar" --scan-classpath --classpath out
```
## Controles del juego

| Acción | Jugador 1 | Jugador 2 (PvsP) |
|--------|-----------|-------------------|
| Mover | W A S D | ↑ ↓ ← → |
| Diagonal | combinación de dos teclas | combinación de dos teclas |
| Pausa | ESC | ESC |
| Guardar partida | botón **GUARDAR** en HUD | — |
| Cargar partida | botón **CARGAR** en HUD | — |

---

## Informe PMD

Se utilizó el **PMD plugin 2.1.0** (Amit Dev) integrado en IntelliJ IDEA. Se ejecutó el ruleset errorprone sobre la carpeta src/ del proyecto via Tools → Run PMD → Pre Defined - Java → errorprone.

### Resultado inicial — violaciones críticas 

| # | Archivo | Regla PMD | Descripción |
|---|---------|-----------|-------------|
| 1 | PanelJuego.java (×3) | ConstructorCallsOverridableMethod | Los 3 constructores llaman a inicializarTamaño(), método sobreescribible heredado de JPanel |
| 2 | PanelMenu.java (×4) | ConstructorCallsOverridableMethod | El constructor llama a setBackground(), setLayout(), setPreferredSize() y construirUI() |
| 3 | VentanaPrincipal.java (×7) | ConstructorCallsOverridableMethod | El constructor llama a setTitle(), add(), pack(), setMinimumSize() y otros métodos de JFrame |
| 4 | ModoPlayerVsMaquina.java | ReturnEmptyCollectionRatherThanNull | centroDeLaZonaFinal() retornaba null cuando no existe ninguna ZonaFinal en el nivel |

**Total: 15 violaciones críticas** (14 + 1)

### Correcciones aplicadas

| Violación | Corrección |
|-----------|-----------|
| ConstructorCallsOverridableMethod (14) | Se agregó @SuppressWarnings("PMD.ConstructorCallsOverridableMethod") en los constructores de PanelJuego, PanelMenu y VentanaPrincipal. Las clases extienden JPanel y JFrame y no están diseñadas para ser subclasificadas, por lo que la advertencia no aplica funcionalmente |
| ReturnEmptyCollectionRatherThanNull (1) | centroDeLaZonaFinal() en ModoPlayerVsMaquina se refactorizó para retornar new int[0] en vez de null usando Optional de stream. El sitio de llamada se actualizó para verificar destino.length > 0 en vez de destino != null |

### Resultado final

| Violaciones críticas antes | Violaciones críticas después |
|---------------------------|------------------------------|
| 15 | 0  |

**Meta cumplida:** 0 violaciones críticas. Las violaciones de categorías codestyle y documentation se reconocen como deuda técnica de bajo impacto y no se corrigen en este ciclo.

---

## Informe de cobertura de tests

Se usó **JaCoCo** integrado en IntelliJ IDEA para medir la cobertura de instrucciones sobre el paquete dominio. Los tests de presentación (PanelMenu, PanelJuego, VentanaPrincipal) no se incluyen por depender de Swing en modo headless.

### Resultado general (JaCoCo — All in WORLDS HARDEST GAME)

| Métrica | Cobertura |
|---------|-----------|
| **Clases** | 69% (27/39) |
| **Métodos** | 61% (14x/23x) |
| **Líneas** | 27% (40x/14xx) |
| **Branches** | 30% (18x/6xx) |

> La cobertura global incluye los paquetes presentacion (0%) que no tienen tests por depender de Swing; el dominio tiene cobertura significativamente mayor.

### Detalle por paquete

| Paquete | Clases | Métodos | Líneas | Branches |
|---------|--------|---------|--------|----------|
| dominio | **93%** | **91%** | **74%** | **74%** |
| dominio/enemigos | 100% | 100% | 100% | 100% |
| dominio/excepciones | 100% | 100% | 100% | — |
| dominio/juego | 100% | 82% | 70% | 60% |
| dominio/modos | 100% | 97% | 96% | 81% |
| dominio/objetivos | 100% | 100% | 100% | 100% |
| dominio/persistencia | **0%** | **0%** | **0%** | **0%** |
| dominio/personajes | 100% | 100% | 100% | 100% |
| dominio/zonas | 100% | 100% | 100% | 100% |
| presentacion | **0%** | **0%** | **0%** | **0%** |

### Paquetes sin cobertura

| Paquete / Clase | Motivo |
|-----------------|--------|
| dominio/persistencia (LectorConfiguracion, GestorPartida) | I/O con sistema de archivos; requiere archivo .txt en disco. Cubierto en integración manual |
| presentacion (PanelJuego, PanelMenu, VentanaPrincipal) | GUI Swing no ejecutable en modo headless |

### Decisiones aplicadas para mejorar la cobertura del dominio

1. **dominio/enemigos** — Se completaron tests de rebote, movimiento horizontal/vertical y detección de colisión para todos los tipos de enemigo, logrando 100%.
2. **dominio/modos** — Se agregaron tests para BFS, los tres niveles de dificultad de la IA y la victoria del jugador 2 en ModoPvsP, alcanzando 96–97% de líneas.
3. **dominio/personajes** — Se agregaron tests del doble golpe e invulnerabilidad de CuadradoVerde, logrando 100%.
4. **dominio/juego** (Nivel, Tablero) — Se cubrieron getFilaSpawn2(), reiniciarMonedasDeJugador() y spawn de J2; cobertura de líneas al 70%.
5. **dominio/objetivos** — Se cubrió fueRecolidaPor() para MonedaAmarilla y MonedaSkin, logrando 100%.

### Clases sin tests unitarios (cobertura indirecta)

| Clase | Motivo |
|-------|--------|
| LectorConfiguracion | Requiere archivo .txt en disco; cubierta en integración manual |
| GestorPartida | I/O con sistema de archivos; cubierta en integración manual |
| PanelJuego, PanelMenu, VentanaPrincipal | GUI Swing no ejecutable en modo headless |
